from django.apps import AppConfig


class LmsappAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'LMSapp_admin'
